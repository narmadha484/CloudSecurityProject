import json
import streamlit as st
from datetime import datetime

st.set_page_config(page_title="AI Cloud Security Dashboard", layout="wide")

st.title("🔐 AI-Driven Cloud Security Dashboard")

try:
    with open("security_report.json", "r") as f:
        report = json.load(f)

    st.success(f"Last Scan Time: {report['scan_time']}")
    st.warning(f"Total Findings: {report['total_findings']}")

    for finding in report["findings"]:
        with st.expander(f"🚨 {finding['service']} | {finding['issue']}"):
            st.write(f"**Resource:** {finding['resource']}")
            st.write(f"**Severity:** {finding['severity']}")
            st.write("**AI Explanation:**")
            st.info(finding["explanation"])

            if "auto_fix_status" in finding:
                st.write("**Auto-Fix Status:**")
                st.success(finding["auto_fix_status"])

except Exception as e:
    st.error("Security report not found. Run scanner first.")

