import json
import os
import datetime
from openai import OpenAI

# Initialize OpenAI client (reads from OPENAI_API_KEY env variable)
client = OpenAI()

CACHE_FILE = "ai_cache.json"

# Load cache if exists
if os.path.exists(CACHE_FILE):
    with open(CACHE_FILE, "r") as f:
        ai_cache = json.load(f)
else:
    ai_cache = {}

def generate_ai_explanation(issue, service, resource, severity):
    """
    Generates AI-based explanation with caching.
    """
    cache_key = f"{service}:{issue}"

    # Return cached explanation if exists
    if cache_key in ai_cache:
        return ai_cache[cache_key]

    prompt = f"""
You are a cloud security assistant.

Explain this AWS security issue in simple, human-readable language.

Service: {service}
Resource: {resource}
Issue: {issue}
Severity: {severity}

Include:
1. What the issue is
2. Why it is dangerous
3. What can happen if ignored
4. Recommended fix (short)
"""

    try:
        response = client.chat.completions.create(
            model="gpt-4.1-mini",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=220
        )

        explanation = response.choices[0].message.content.strip()

    except Exception:
        # Fallback if AI fails
        explanation = (
            "This configuration violates AWS security best practices. "
            "It may expose resources to unauthorized access and should be fixed immediately."
        )

    # Save to cache
    ai_cache[cache_key] = explanation
    with open(CACHE_FILE, "w") as f:
        json.dump(ai_cache, f, indent=4)

    return explanation


def generate_report(findings):
    report = {
        "scan_time": datetime.datetime.utcnow().isoformat(),
        "total_findings": len(findings),
        "findings": []
    }

    for f in findings:
        f["explanation"] = generate_ai_explanation(
            issue=f["issue"],
            service=f["service"],
            resource=f["resource"],
            severity=f["severity"]
        )
        report["findings"].append(f)

    with open("security_report.json", "w") as f:
        json.dump(report, f, indent=4)

    print("📄 Security report generated with AI explanations")


