
from s3_scanner import scan_s3_buckets
from iam_scanner import scan_iam_security
from ec2_scanner import scan_ec2_security
from alert_system import send_alert
from report_generator import generate_report
from ai_explainer import explain_findings
from remediation_engine import fix_ec2_ssh
from ai_explainer import explain_fix


AUTO_FIX = True

s3_findings = scan_s3_buckets()
iam_findings = scan_iam_security()
ec2_findings = scan_ec2_security()

all_findings = []
all_findings.extend(s3_findings)
all_findings.extend(iam_findings)
all_findings.extend(ec2_findings)

print("\n=== Scan Completed ===")

explained_findings = []

for finding in all_findings:

    # AUTO-FIX only for critical SSH issue
    if AUTO_FIX and finding["issue"] == "Port 22 open to world (0.0.0.0/0)":
        fix_result = fix_ec2_ssh(finding)
        finding["auto_fix_status"] = fix_result

        fix_explanation = explain_fix(
            issue=finding["issue"],
            action=fix_result,
            resource=finding["resource"]
        )

        finding["fix_explanation"] = fix_explanation

    explained_findings.append(finding)

# Generate report ONCE
generate_report(explained_findings)

# Send alert ONCE
send_alert(explained_findings)

print("📄 Report generated with AI explanations")
print("📩 Alert sent via SNS")

print("\n=== PROGRAM COMPLETED ===\n")

