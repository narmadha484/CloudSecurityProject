def explain_fix(issue, action, resource):
    """
    Returns a simple AI-style explanation for the remediation applied.
    """
    explanation = (
        f"Remediation for '{issue}' on resource '{resource}' executed. "
        f"Action performed: {action}."
    )
    return explanation
def explain_findings(findings):
    explanations = []

    for f in findings:
        service = f.get("service", "UNKNOWN")
        issue = f.get("issue", "")
        severity = f.get("severity", "LOW")

        if service == "EC2":
            if "public IP" in issue.lower():
                explanation = (
                    "EC2 instance is publicly reachable from the internet. "
                    "This increases attack surface and may allow unauthorized access."
                )
            elif "port" in issue.lower():
                explanation = (
                    "Security Group allows inbound traffic from 0.0.0.0/0. "
                    "This means anyone on the internet can attempt to connect."
                )
            elif "not encrypted" in issue.lower():
                explanation = (
                    "EBS volume is not encrypted. "
                    "If data is compromised or snapshot is leaked, sensitive data may be exposed."
                )
            else:
                explanation = "EC2 security misconfiguration detected."

        elif service == "IAM":
            if "without MFA" in issue.lower():
                explanation = (
                    "IAM user does not have Multi-Factor Authentication enabled. "
                    "If credentials are compromised, attacker can log in directly."
                )
            elif "access key" in issue.lower():
                explanation = (
                    "Old access keys increase risk of long-term credential leakage. "
                    "Best practice is rotating keys every 90 days."
                )
            elif "root" in issue.lower():
                explanation = (
                    "Root account does not have MFA enabled. "
                    "This is a critical risk as root has full AWS access."
                )
            else:
                explanation = "IAM security risk detected."

        elif service == "S3":
            if "public" in issue.lower():
                explanation = (
                    "S3 bucket is publicly accessible. "
                    "Sensitive data may be exposed to the internet."
                )
            elif "encryption" in issue.lower():
                explanation = (
                    "S3 bucket does not have encryption enabled. "
                    "Data at rest is not protected."
                )
            elif "versioning" in issue.lower():
                explanation = (
                    "Versioning is disabled. "
                    "This increases risk of data loss due to accidental deletion or overwrite."
                )
            else:
                explanation = "S3 security issue detected."

        else:
            explanation = "Security issue detected."

        explanations.append({
            "service": service,
            "resource": f.get("resource"),
            "issue": issue,
            "severity": severity,
            "explanation": explanation
        })

    return explanations

