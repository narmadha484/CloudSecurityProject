import boto3

s3 = boto3.client("s3")

def scan_s3_buckets():
    findings = []

    buckets = s3.list_buckets()["Buckets"]

    print("\n=== S3 Security Scan ===")

    for bucket in buckets:
        name = bucket["Name"]
        print(f"\n🔍 Bucket: {name}")

        # 1️⃣ Public access check
        try:
            acl = s3.get_bucket_acl(Bucket=name)
            public = any(
                grant["Grantee"].get("URI") ==
                "http://acs.amazonaws.com/groups/global/AllUsers"
                for grant in acl["Grants"]
            )

            if public:
                print("  - Public Access: YES ❌")
                findings.append({
                    "resource": name,
                    "issue": "S3 bucket is public",
                    "severity": "CRITICAL"
                })
            else:
                print("  - Public Access: NO ✅")

        except Exception:
            print("  - Public Access: ERROR")

        # 2️⃣ Encryption check
        try:
            s3.get_bucket_encryption(Bucket=name)
            print("  - Encryption: ENABLED 🔐")
        except s3.exceptions.ClientError:
            print("  - Encryption: NOT ENABLED ⚠️")
            findings.append({
                "resource": name,
                "issue": "S3 encryption not enabled",
                "severity": "HIGH"
            })

        # 3️⃣ Versioning check
        try:
            ver = s3.get_bucket_versioning(Bucket=name)
            status = ver.get("Status", "Disabled")

            if status != "Enabled":
                print("  - Versioning: Disabled ❌")
                findings.append({
                    "resource": name,
                    "issue": "S3 versioning disabled",
                    "severity": "MEDIUM"
                })
            else:
                print("  - Versioning: Enabled ✅")

        except Exception:
            print("  - Versioning: ERROR")

    return findings

